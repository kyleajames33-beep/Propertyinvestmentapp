---
title: Preparing your finances for your first investment property
persona: inv-new
journey_stage: Finance Preparation
referral_ctas: [mortgage_broker, accountant]
sources: [APRA Monthly Banking Statistics, 2024; ASIC Moneysmart, 2024; ATO Rental Income and Deductions, 2024; Canstar Investment Loan Comparison, 2024; CoreLogic Housing Market Update, 2024; MFAA Industry Intelligence, 2024; Reserve Bank of Australia, 2024; RBA Financial Stability Review, 2024]
last_reviewed: 2026-04-19
---

# Preparing your finances for your first investment property

Financing an investment property is different from financing a home you plan to live in. Lenders apply stricter criteria, interest rates are typically higher, and the way your rental income and existing debts are assessed can significantly affect your borrowing capacity. This guide covers what new investors need to understand before applying for their first investment loan.

## How investment loans differ from owner-occupier loans

Investment loans and owner-occupier loans may look similar on the surface, but lenders treat them differently in several important ways.

### Interest rate differences

Investment loans typically carry higher interest rates than owner-occupier loans. The difference can range from 0.25% to 0.75% or more, depending on the lender and the loan product. This premium reflects the lender's assessment that investment properties carry higher risk: rental income can fluctuate, tenants may default, and investors may be more willing to walk away from a property that is not their primary residence. [Source: Canstar Investment Loan Comparison, 2024]

Some lenders offer the same rate for both loan types, but these are the exception rather than the rule. When comparing loans, ensure you are looking at investment loan rates, not owner-occupier rates, as the difference can amount to thousands of dollars per year on a substantial loan.

### Loan-to-value ratio (LVR) requirements

While owner-occupiers can borrow up to 95% of a property's value (with LMI), investors are generally restricted to 90% or less. Many lenders cap investment lending at 80% LVR, particularly for new investors. This means you need a larger deposit or more equity to fund an investment purchase compared to an equivalent owner-occupied property. [Source: APRA Monthly Banking Statistics, 2024]

Following regulatory changes introduced by the Australian Prudential Regulation Authority (APRA) in recent years, lenders have tightened investment lending standards significantly. Interest-only lending and high-LVR investment loans face additional scrutiny. [Source: RBA Financial Stability Review, 2024]

## Deposit requirements: why investors often need more

The deposit required for an investment property depends on your LVR limit, the property price, and whether you are funding the deposit from savings or equity.

### Minimum deposits

At an 80% LVR cap, you need a 20% deposit plus costs. On a $600,000 investment property, that means $120,000 in cash or equity, plus stamp duty, legal fees, and inspection costs. If your lender caps investment lending at 90% LVR and you are willing to pay LMI, you could reduce this to $60,000 plus costs, though LMI premiums on investment properties are higher than for owner-occupiers. [Source: Canstar Investment Loan Comparison, 2024]

### Using equity instead of cash

Many first-time investors fund their deposit using equity in their owner-occupied home rather than cash savings. If your home is worth $800,000 and your mortgage is $400,000, you have $400,000 in equity. A lender may allow you to access up to 80% of your home's value ($640,000) minus your existing mortgage, giving you $240,000 in usable equity. This can serve as the deposit for your investment property. [Source: ASIC Moneysmart, 2024]

Using equity to invest increases your overall debt and means your owner-occupied home is effectively security for the investment purchase. If the investment fails and you cannot meet repayments, both properties are at risk. Understand this risk fully before proceeding.

### Stamp duty for investors

Investors generally do not qualify for first home buyer stamp duty concessions or exemptions. You will pay full stamp duty on the purchase, which varies by state. In Victoria, stamp duty on a $600,000 investment property is approximately $31,000. In Queensland, it is approximately $20,000. Budget for this as part of your total cash requirement. [Source: CoreLogic Housing Market Update, 2024]

## Rental income: how lenders count it

Rental income from your investment property improves your serviceability position, but lenders do not count every dollar you expect to receive.

### The 80% shading rule

Most lenders apply a "shading" or discount to rental income, typically counting 70% to 80% of gross rent in their serviceability calculations. This accounts for potential vacancies, property management fees, maintenance costs, and other expenses. If you expect $500 per week in rent ($26,000 annually), the lender may only count $20,800 (80%) or $18,200 (70%) in their assessment. [Source: Canstar Investment Loan Comparison, 2024]

Some lenders are more generous with rental income shading, particularly if you use a professional property manager or if the property is in a high-demand rental area. A mortgage broker with investment lending experience can identify which lenders take a more favourable approach.

### Existing rental income

If you already own an investment property, the same shading rules apply to that rental income. The lender will also verify that the rent has been consistently received through bank statements or a lease agreement.

## Existing debt: how your owner-occupier mortgage affects investment borrowing

Your existing owner-occupier mortgage is the single biggest factor that will limit your investment borrowing capacity. Lenders assess your existing debts in full, even if your investment property will be positively geared.

### Serviceability assessment

When assessing your ability to service an additional loan, lenders apply a buffer to your existing mortgage repayments. They typically assess your existing loan at a higher "assessment rate" than you are actually paying, often around 3% above the current rate or a minimum floor rate (whichever is higher). This ensures you could still afford the debt if interest rates rise significantly. [Source: APRA Monthly Banking Statistics, 2024]

For example, if you currently pay 6% on your owner-occupied mortgage, the lender may assess your capacity to service that loan at 9%. On a $400,000 mortgage, your actual repayment might be $2,400 per month, but the lender will count $3,200 per month in their calculations. This substantially reduces your remaining borrowing capacity. [Source: Reserve Bank of Australia, 2024]

### Credit card and personal debt

As with owner-occupied lending, all existing credit card limits count against your borrowing capacity. Reduce or close unnecessary credit cards before applying. Personal loans and car loans also reduce your capacity. Consider whether consolidating or paying down these debts will improve your position more than using the cash for a larger deposit. [Source: ASIC Moneysmart, 2024]

## Interest-only loans: pros, cons, and current lender attitudes

Interest-only loans were once the default choice for property investors, but regulatory changes have made them more expensive and harder to obtain.

### How interest-only loans work

With an interest-only loan, you pay only the interest charged each month for a set period, typically five to ten years. Your principal balance does not reduce during this time. After the interest-only period expires, the loan reverts to principal and interest repayments for the remaining term, which means your repayments will increase significantly. [Source: ASIC Moneysmart, 2024]

### Why investors use them

The primary appeal is cash flow management. Lower monthly repayments mean the property is more likely to be cash flow positive or have a smaller shortfall. Additionally, because you are not paying down principal, you preserve tax-deductible debt while potentially directing spare cash flow toward non-deductible debt like your owner-occupier mortgage. [Source: ATO Rental Income and Deductions, 2024]

### Current lender attitudes

APRA has imposed limits on interest-only lending as a proportion of new loans, and most lenders now charge a premium for interest-only loans compared to principal and interest loans. This premium can be 0.2% to 0.5% or more. Lenders also apply stricter serviceability tests to interest-only applications. [Source: RBA Financial Stability Review, 2024]

Some lenders have withdrawn interest-only products for new investors altogether or require larger deposits for interest-only loans. If you are considering interest-only, speak to a broker about which lenders are still competitive in this space.

### Risks to consider

The main risk is repayment shock when the interest-only period ends. If property values have not risen and you have not built equity through principal repayments, you may find yourself with higher repayments and limited refinancing options. Interest-only loans also cost more over the life of the loan because you are paying interest on the full principal balance for longer. [Source: ASIC Moneysmart, 2024]

## Loan structure: offset vs redraw, fixed vs variable considerations

How you structure your investment loan affects your cash flow, tax position, and flexibility.

### Offset account vs redraw facility

An offset account is a transaction account linked to your loan. The balance in the offset account reduces the interest you pay on your loan. If you have a $500,000 loan and $50,000 in your offset account, you only pay interest on $450,000. A redraw facility allows you to withdraw extra repayments you have made above your minimum required amount. [Source: Canstar Investment Loan Comparison, 2024]

For investors, offset accounts are generally preferable to redraw facilities for tax reasons. If you redraw funds from an investment loan for personal use, the tax deductibility of that portion of the loan may be affected. Funds in an offset account keep the loan balance unchanged while achieving the same interest savings. Speak to an accountant about your specific situation. [Source: ATO Rental Income and Deductions, 2024]

### Fixed vs variable interest rates

A fixed rate locks in your interest rate for a set period, typically one to five years, giving you certainty about your repayments. A variable rate fluctuates with market conditions and can go up or down. [Source: Reserve Bank of Australia, 2024]

Many investors choose a split loan: part fixed for certainty, part variable for flexibility. This can be particularly useful when you are starting out and want to manage cash flow risk while retaining the ability to make extra repayments or access an offset account. Consider your risk tolerance, cash flow position, and expectations about interest rate movements when deciding. [Source: Canstar Investment Loan Comparison, 2024]

## Pre-approval for investors: differences and extra requirements

Pre-approval for an investment loan follows a similar process to owner-occupied pre-approval but with additional requirements.

### Rental income estimates

The lender will want to see evidence supporting your expected rental income. This typically includes a rental appraisal from a licensed real estate agent, comparable rental listings for similar properties in the area, or a signed lease agreement if the property already has tenants. [Source: MFAA Industry Intelligence, 2024]

### Property-specific assessment

Investment pre-approvals are often property-specific. The lender may impose conditions related to the property type, location, and size. Some lenders have restrictions on studio apartments, properties in certain postcodes, or high-density developments. If you are buying off the plan, additional conditions will apply. [Source: Canstar Investment Loan Comparison, 2024]

### Investment policy requirements

Lenders may require you to demonstrate previous property ownership experience, even for your first investment. They will also assess your understanding of the costs involved, including property management fees, council rates, insurance, maintenance, and potential vacancy periods.

## Cashflow evidence: what lenders want to see

Lenders want confidence that you can afford the investment property even during periods of vacancy or unexpected expenses.

### What to provide

In addition to the standard income and expense documentation, investors should prepare:

- A detailed budget showing expected rental income and all property-related expenses
- Evidence of cash reserves or a buffer to cover several months of vacancy
- Bank statements showing consistent savings behaviour
- If self-employed, additional evidence of business stability [Source: MFAA Industry Intelligence, 2024]

### The importance of buffers

Successful property investment requires financial buffers. Lenders look favourably on applicants who have demonstrated they maintain savings beyond what is needed for the deposit. Aim to have at least three to six months of property expenses held in reserve, separate from your personal emergency fund. This demonstrates financial discipline and reduces the lender's perception of risk. [Source: ASIC Moneysmart, 2024]

## How a mortgage broker and accountant can help

A mortgage broker who specialises in investment lending understands which lenders are investor-friendly, how to structure loans for tax efficiency, and how to maximise your borrowing capacity. They can compare products across dozens of lenders rather than the handful you might research yourself. [Source: MFAA Industry Intelligence, 2024]

An accountant with property investment experience can advise on structuring, tax deductions, negative gearing, depreciation, and how your investment fits into your broader financial plan. The right accountant pays for themselves many times over through tax savings and strategic advice. [Source: ATO Rental Income and Deductions, 2024]

When selecting professionals, ask about their experience with investment clients, how many lenders they work with (for brokers), and whether they hold relevant qualifications. Be wary of anyone who guarantees returns or pushes you toward a specific property. Your broker and accountant should provide advice tailored to your situation, not sell you a product.

---

**General advice disclaimer**

This information is of a general nature only and does not constitute financial advice or take into account your personal objectives, financial situation, or needs. You should consider whether the information is appropriate for your circumstances and, where appropriate, seek professional advice from a qualified financial adviser, mortgage broker, or accountant before making any financial decisions. Past performance is not indicative of future results. Lending criteria, interest rates, and government programs change regularly. Tax laws are complex and subject to change. Verify all details with relevant authorities and your chosen lender before proceeding.
